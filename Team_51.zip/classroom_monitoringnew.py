import os
import sys

# Suppress TensorFlow C++ logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
sys.stderr = open(os.devnull, 'w') 
import cv2
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import mediapipe as mp


model = tf.keras.applications.MobileNetV2(weights='imagenet')

mp_face = mp.solutions.face_detection
mp_drawing = mp.solutions.drawing_utils

def preprocess_image(img_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (224, 224))
    img = tf.keras.applications.mobilenet_v2.preprocess_input(img)
    img = np.expand_dims(img, axis=0)
    return img

def predict_activity(img_path):
    img = preprocess_image(img_path)
    preds = model.predict(img)
    decoded_preds = tf.keras.applications.mobilenet_v2.decode_predictions(preds, top=3)[0]
    print("\n🧠 Top Predictions:")
    for i, (imagenet_id, label, confidence) in enumerate(decoded_preds):
        print(f"{i+1}. {label} ({confidence*100:.2f}%)")

def detect_faces_mediapipe(img_path):
    image = cv2.imread(img_path)
    if image is None:
        print("❌ Could not read the image.")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    face_count = 0

    with mp_face.FaceDetection(model_selection=1, min_detection_confidence=0.5) as face_detection:
        results = face_detection.process(image_rgb)

        if results.detections:
            for detection in results.detections:
                face_count += 1
                bbox = detection.location_data.relative_bounding_box
                h, w, _ = image.shape
                x1 = int(bbox.xmin * w)
                y1 = int(bbox.ymin * h)
                width = int(bbox.width * w)
                height = int(bbox.height * h)
                cv2.rectangle(image, (x1, y1), (x1 + width, y1 + height), (0, 255, 0), 2)

    # Feedback
    print(f"\n🧑 Detected {face_count} face(s) in the classroom.")
    if face_count == 0:
        print("⚠️ Alert: No people detected! Flagging for review.")
    elif face_count < 3:
        print("⚠️ Warning: Very few trainees detected. Needs review.")
    else:
        print("✅ Sufficient trainees present.")

    return image

def show_image_with_prediction(img_path):
    img_with_faces = detect_faces_mediapipe(img_path)
    if img_with_faces is None:
        return
    img_rgb = cv2.cvtColor(img_with_faces, cv2.COLOR_BGR2RGB)
    plt.imshow(img_rgb)
    plt.axis('off')
    plt.title("Classroom Monitoring")
    plt.show()

    predict_activity(img_path)

image_path = r"C:\Users\Lenovo\Desktop\code\classroom5.jpg"
show_image_with_prediction(image_path)
